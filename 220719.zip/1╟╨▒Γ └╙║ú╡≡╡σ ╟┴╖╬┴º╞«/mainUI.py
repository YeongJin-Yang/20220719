# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainUI.ui'
##
## Created by: Qt User Interface Compiler version 6.4.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGridLayout, QLayout, QMainWindow,
    QMenuBar, QPushButton, QSizePolicy, QStatusBar,
    QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(934, 698)
        sizePolicy = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(MainWindow.sizePolicy().hasHeightForWidth())
        MainWindow.setSizePolicy(sizePolicy)
        MainWindow.setMaximumSize(QSize(16777215, 16777215))
        font = QFont()
        font.setFamilies([u"Bradley Hand ITC"])
        MainWindow.setFont(font)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayoutWidget = QWidget(self.centralwidget)
        self.gridLayoutWidget.setObjectName(u"gridLayoutWidget")
        self.gridLayoutWidget.setGeometry(QRect(80, 60, 644, 331))
        self.gridLayout = QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setSizeConstraint(QLayout.SetMaximumSize)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.btn30 = QPushButton(self.gridLayoutWidget)
        self.btn30.setObjectName(u"btn30")
        sizePolicy1 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.btn30.sizePolicy().hasHeightForWidth())
        self.btn30.setSizePolicy(sizePolicy1)
        self.btn30.setCheckable(True)

        self.gridLayout.addWidget(self.btn30, 3, 0, 1, 1)

        self.btn77 = QPushButton(self.gridLayoutWidget)
        self.btn77.setObjectName(u"btn77")
        sizePolicy1.setHeightForWidth(self.btn77.sizePolicy().hasHeightForWidth())
        self.btn77.setSizePolicy(sizePolicy1)
        self.btn77.setCheckable(True)
        self.btn77.setChecked(True)

        self.gridLayout.addWidget(self.btn77, 7, 7, 1, 1)

        self.btn76 = QPushButton(self.gridLayoutWidget)
        self.btn76.setObjectName(u"btn76")
        sizePolicy1.setHeightForWidth(self.btn76.sizePolicy().hasHeightForWidth())
        self.btn76.setSizePolicy(sizePolicy1)
        self.btn76.setCheckable(True)

        self.gridLayout.addWidget(self.btn76, 7, 6, 1, 1)

        self.btn37 = QPushButton(self.gridLayoutWidget)
        self.btn37.setObjectName(u"btn37")
        sizePolicy1.setHeightForWidth(self.btn37.sizePolicy().hasHeightForWidth())
        self.btn37.setSizePolicy(sizePolicy1)
        self.btn37.setCheckable(True)

        self.gridLayout.addWidget(self.btn37, 3, 7, 1, 1)

        self.btn26 = QPushButton(self.gridLayoutWidget)
        self.btn26.setObjectName(u"btn26")
        sizePolicy1.setHeightForWidth(self.btn26.sizePolicy().hasHeightForWidth())
        self.btn26.setSizePolicy(sizePolicy1)
        self.btn26.setCheckable(True)

        self.gridLayout.addWidget(self.btn26, 2, 6, 1, 1)

        self.btn67 = QPushButton(self.gridLayoutWidget)
        self.btn67.setObjectName(u"btn67")
        sizePolicy1.setHeightForWidth(self.btn67.sizePolicy().hasHeightForWidth())
        self.btn67.setSizePolicy(sizePolicy1)
        self.btn67.setCheckable(True)

        self.gridLayout.addWidget(self.btn67, 6, 7, 1, 1)

        self.btn23 = QPushButton(self.gridLayoutWidget)
        self.btn23.setObjectName(u"btn23")
        sizePolicy1.setHeightForWidth(self.btn23.sizePolicy().hasHeightForWidth())
        self.btn23.setSizePolicy(sizePolicy1)
        self.btn23.setCheckable(True)

        self.gridLayout.addWidget(self.btn23, 2, 3, 1, 1)

        self.btn60 = QPushButton(self.gridLayoutWidget)
        self.btn60.setObjectName(u"btn60")
        sizePolicy1.setHeightForWidth(self.btn60.sizePolicy().hasHeightForWidth())
        self.btn60.setSizePolicy(sizePolicy1)
        self.btn60.setCheckable(True)

        self.gridLayout.addWidget(self.btn60, 6, 0, 1, 1)

        self.btn46 = QPushButton(self.gridLayoutWidget)
        self.btn46.setObjectName(u"btn46")
        sizePolicy1.setHeightForWidth(self.btn46.sizePolicy().hasHeightForWidth())
        self.btn46.setSizePolicy(sizePolicy1)
        self.btn46.setCheckable(True)

        self.gridLayout.addWidget(self.btn46, 4, 6, 1, 1)

        self.btn73 = QPushButton(self.gridLayoutWidget)
        self.btn73.setObjectName(u"btn73")
        sizePolicy1.setHeightForWidth(self.btn73.sizePolicy().hasHeightForWidth())
        self.btn73.setSizePolicy(sizePolicy1)
        self.btn73.setCheckable(True)

        self.gridLayout.addWidget(self.btn73, 7, 3, 1, 1)

        self.btn50 = QPushButton(self.gridLayoutWidget)
        self.btn50.setObjectName(u"btn50")
        sizePolicy1.setHeightForWidth(self.btn50.sizePolicy().hasHeightForWidth())
        self.btn50.setSizePolicy(sizePolicy1)
        self.btn50.setCheckable(True)

        self.gridLayout.addWidget(self.btn50, 5, 0, 1, 1)

        self.btn44 = QPushButton(self.gridLayoutWidget)
        self.btn44.setObjectName(u"btn44")
        sizePolicy1.setHeightForWidth(self.btn44.sizePolicy().hasHeightForWidth())
        self.btn44.setSizePolicy(sizePolicy1)
        self.btn44.setCheckable(True)

        self.gridLayout.addWidget(self.btn44, 4, 4, 1, 1)

        self.btn10 = QPushButton(self.gridLayoutWidget)
        self.btn10.setObjectName(u"btn10")
        sizePolicy1.setHeightForWidth(self.btn10.sizePolicy().hasHeightForWidth())
        self.btn10.setSizePolicy(sizePolicy1)
        self.btn10.setCheckable(True)

        self.gridLayout.addWidget(self.btn10, 1, 0, 1, 1)

        self.btn56 = QPushButton(self.gridLayoutWidget)
        self.btn56.setObjectName(u"btn56")
        sizePolicy1.setHeightForWidth(self.btn56.sizePolicy().hasHeightForWidth())
        self.btn56.setSizePolicy(sizePolicy1)
        self.btn56.setCheckable(True)

        self.gridLayout.addWidget(self.btn56, 5, 6, 1, 1)

        self.btn02 = QPushButton(self.gridLayoutWidget)
        self.btn02.setObjectName(u"btn02")
        sizePolicy1.setHeightForWidth(self.btn02.sizePolicy().hasHeightForWidth())
        self.btn02.setSizePolicy(sizePolicy1)
        self.btn02.setCheckable(True)

        self.gridLayout.addWidget(self.btn02, 0, 2, 1, 1)

        self.btn41 = QPushButton(self.gridLayoutWidget)
        self.btn41.setObjectName(u"btn41")
        sizePolicy1.setHeightForWidth(self.btn41.sizePolicy().hasHeightForWidth())
        self.btn41.setSizePolicy(sizePolicy1)
        self.btn41.setCheckable(True)

        self.gridLayout.addWidget(self.btn41, 4, 1, 1, 1)

        self.btn43 = QPushButton(self.gridLayoutWidget)
        self.btn43.setObjectName(u"btn43")
        sizePolicy1.setHeightForWidth(self.btn43.sizePolicy().hasHeightForWidth())
        self.btn43.setSizePolicy(sizePolicy1)
        self.btn43.setCheckable(True)

        self.gridLayout.addWidget(self.btn43, 4, 3, 1, 1)

        self.btn51 = QPushButton(self.gridLayoutWidget)
        self.btn51.setObjectName(u"btn51")
        sizePolicy1.setHeightForWidth(self.btn51.sizePolicy().hasHeightForWidth())
        self.btn51.setSizePolicy(sizePolicy1)
        self.btn51.setCheckable(True)

        self.gridLayout.addWidget(self.btn51, 5, 1, 1, 1)

        self.btn21 = QPushButton(self.gridLayoutWidget)
        self.btn21.setObjectName(u"btn21")
        sizePolicy1.setHeightForWidth(self.btn21.sizePolicy().hasHeightForWidth())
        self.btn21.setSizePolicy(sizePolicy1)
        self.btn21.setCheckable(True)

        self.gridLayout.addWidget(self.btn21, 2, 1, 1, 1)

        self.btn07 = QPushButton(self.gridLayoutWidget)
        self.btn07.setObjectName(u"btn07")
        sizePolicy1.setHeightForWidth(self.btn07.sizePolicy().hasHeightForWidth())
        self.btn07.setSizePolicy(sizePolicy1)
        self.btn07.setCheckable(True)

        self.gridLayout.addWidget(self.btn07, 0, 7, 1, 1)

        self.btn14 = QPushButton(self.gridLayoutWidget)
        self.btn14.setObjectName(u"btn14")
        sizePolicy1.setHeightForWidth(self.btn14.sizePolicy().hasHeightForWidth())
        self.btn14.setSizePolicy(sizePolicy1)
        self.btn14.setCheckable(True)

        self.gridLayout.addWidget(self.btn14, 1, 4, 1, 1)

        self.btn25 = QPushButton(self.gridLayoutWidget)
        self.btn25.setObjectName(u"btn25")
        sizePolicy1.setHeightForWidth(self.btn25.sizePolicy().hasHeightForWidth())
        self.btn25.setSizePolicy(sizePolicy1)
        self.btn25.setCheckable(True)

        self.gridLayout.addWidget(self.btn25, 2, 5, 1, 1)

        self.btn34 = QPushButton(self.gridLayoutWidget)
        self.btn34.setObjectName(u"btn34")
        sizePolicy1.setHeightForWidth(self.btn34.sizePolicy().hasHeightForWidth())
        self.btn34.setSizePolicy(sizePolicy1)
        self.btn34.setCheckable(True)

        self.gridLayout.addWidget(self.btn34, 3, 4, 1, 1)

        self.btn45 = QPushButton(self.gridLayoutWidget)
        self.btn45.setObjectName(u"btn45")
        sizePolicy1.setHeightForWidth(self.btn45.sizePolicy().hasHeightForWidth())
        self.btn45.setSizePolicy(sizePolicy1)
        self.btn45.setCheckable(True)

        self.gridLayout.addWidget(self.btn45, 4, 5, 1, 1)

        self.btn00 = QPushButton(self.gridLayoutWidget)
        self.btn00.setObjectName(u"btn00")
        sizePolicy1.setHeightForWidth(self.btn00.sizePolicy().hasHeightForWidth())
        self.btn00.setSizePolicy(sizePolicy1)
        self.btn00.setCheckable(True)
        self.btn00.setChecked(True)

        self.gridLayout.addWidget(self.btn00, 0, 0, 1, 1)

        self.btn24 = QPushButton(self.gridLayoutWidget)
        self.btn24.setObjectName(u"btn24")
        sizePolicy1.setHeightForWidth(self.btn24.sizePolicy().hasHeightForWidth())
        self.btn24.setSizePolicy(sizePolicy1)
        self.btn24.setCheckable(True)

        self.gridLayout.addWidget(self.btn24, 2, 4, 1, 1)

        self.btn55 = QPushButton(self.gridLayoutWidget)
        self.btn55.setObjectName(u"btn55")
        sizePolicy1.setHeightForWidth(self.btn55.sizePolicy().hasHeightForWidth())
        self.btn55.setSizePolicy(sizePolicy1)
        self.btn55.setCheckable(True)

        self.gridLayout.addWidget(self.btn55, 5, 5, 1, 1)

        self.btn57 = QPushButton(self.gridLayoutWidget)
        self.btn57.setObjectName(u"btn57")
        sizePolicy1.setHeightForWidth(self.btn57.sizePolicy().hasHeightForWidth())
        self.btn57.setSizePolicy(sizePolicy1)
        self.btn57.setCheckable(True)

        self.gridLayout.addWidget(self.btn57, 5, 7, 1, 1)

        self.btn74 = QPushButton(self.gridLayoutWidget)
        self.btn74.setObjectName(u"btn74")
        sizePolicy1.setHeightForWidth(self.btn74.sizePolicy().hasHeightForWidth())
        self.btn74.setSizePolicy(sizePolicy1)
        self.btn74.setCheckable(True)

        self.gridLayout.addWidget(self.btn74, 7, 4, 1, 1)

        self.btn63 = QPushButton(self.gridLayoutWidget)
        self.btn63.setObjectName(u"btn63")
        sizePolicy1.setHeightForWidth(self.btn63.sizePolicy().hasHeightForWidth())
        self.btn63.setSizePolicy(sizePolicy1)
        self.btn63.setCheckable(True)

        self.gridLayout.addWidget(self.btn63, 6, 3, 1, 1)

        self.btn54 = QPushButton(self.gridLayoutWidget)
        self.btn54.setObjectName(u"btn54")
        sizePolicy1.setHeightForWidth(self.btn54.sizePolicy().hasHeightForWidth())
        self.btn54.setSizePolicy(sizePolicy1)
        self.btn54.setCheckable(True)

        self.gridLayout.addWidget(self.btn54, 5, 4, 1, 1)

        self.btn04 = QPushButton(self.gridLayoutWidget)
        self.btn04.setObjectName(u"btn04")
        sizePolicy1.setHeightForWidth(self.btn04.sizePolicy().hasHeightForWidth())
        self.btn04.setSizePolicy(sizePolicy1)
        self.btn04.setCheckable(True)

        self.gridLayout.addWidget(self.btn04, 0, 4, 1, 1)

        self.btn31 = QPushButton(self.gridLayoutWidget)
        self.btn31.setObjectName(u"btn31")
        sizePolicy1.setHeightForWidth(self.btn31.sizePolicy().hasHeightForWidth())
        self.btn31.setSizePolicy(sizePolicy1)
        self.btn31.setCheckable(True)

        self.gridLayout.addWidget(self.btn31, 3, 1, 1, 1)

        self.btn40 = QPushButton(self.gridLayoutWidget)
        self.btn40.setObjectName(u"btn40")
        sizePolicy1.setHeightForWidth(self.btn40.sizePolicy().hasHeightForWidth())
        self.btn40.setSizePolicy(sizePolicy1)
        self.btn40.setCheckable(True)

        self.gridLayout.addWidget(self.btn40, 4, 0, 1, 1)

        self.btn06 = QPushButton(self.gridLayoutWidget)
        self.btn06.setObjectName(u"btn06")
        sizePolicy1.setHeightForWidth(self.btn06.sizePolicy().hasHeightForWidth())
        self.btn06.setSizePolicy(sizePolicy1)
        self.btn06.setCheckable(True)

        self.gridLayout.addWidget(self.btn06, 0, 6, 1, 1)

        self.btn66 = QPushButton(self.gridLayoutWidget)
        self.btn66.setObjectName(u"btn66")
        sizePolicy1.setHeightForWidth(self.btn66.sizePolicy().hasHeightForWidth())
        self.btn66.setSizePolicy(sizePolicy1)
        self.btn66.setCheckable(True)

        self.gridLayout.addWidget(self.btn66, 6, 6, 1, 1)

        self.btn72 = QPushButton(self.gridLayoutWidget)
        self.btn72.setObjectName(u"btn72")
        sizePolicy1.setHeightForWidth(self.btn72.sizePolicy().hasHeightForWidth())
        self.btn72.setSizePolicy(sizePolicy1)
        self.btn72.setCheckable(True)

        self.gridLayout.addWidget(self.btn72, 7, 2, 1, 1)

        self.btn17 = QPushButton(self.gridLayoutWidget)
        self.btn17.setObjectName(u"btn17")
        sizePolicy1.setHeightForWidth(self.btn17.sizePolicy().hasHeightForWidth())
        self.btn17.setSizePolicy(sizePolicy1)
        self.btn17.setCheckable(True)

        self.gridLayout.addWidget(self.btn17, 1, 7, 1, 1)

        self.btn62 = QPushButton(self.gridLayoutWidget)
        self.btn62.setObjectName(u"btn62")
        sizePolicy1.setHeightForWidth(self.btn62.sizePolicy().hasHeightForWidth())
        self.btn62.setSizePolicy(sizePolicy1)
        self.btn62.setCheckable(True)

        self.gridLayout.addWidget(self.btn62, 6, 2, 1, 1)

        self.btn03 = QPushButton(self.gridLayoutWidget)
        self.btn03.setObjectName(u"btn03")
        sizePolicy1.setHeightForWidth(self.btn03.sizePolicy().hasHeightForWidth())
        self.btn03.setSizePolicy(sizePolicy1)
        self.btn03.setCheckable(True)

        self.gridLayout.addWidget(self.btn03, 0, 3, 1, 1)

        self.btn35 = QPushButton(self.gridLayoutWidget)
        self.btn35.setObjectName(u"btn35")
        sizePolicy1.setHeightForWidth(self.btn35.sizePolicy().hasHeightForWidth())
        self.btn35.setSizePolicy(sizePolicy1)
        self.btn35.setCheckable(True)

        self.gridLayout.addWidget(self.btn35, 3, 5, 1, 1)

        self.btn75 = QPushButton(self.gridLayoutWidget)
        self.btn75.setObjectName(u"btn75")
        sizePolicy1.setHeightForWidth(self.btn75.sizePolicy().hasHeightForWidth())
        self.btn75.setSizePolicy(sizePolicy1)
        self.btn75.setCheckable(True)

        self.gridLayout.addWidget(self.btn75, 7, 5, 1, 1)

        self.btn20 = QPushButton(self.gridLayoutWidget)
        self.btn20.setObjectName(u"btn20")
        sizePolicy1.setHeightForWidth(self.btn20.sizePolicy().hasHeightForWidth())
        self.btn20.setSizePolicy(sizePolicy1)
        self.btn20.setCheckable(True)

        self.gridLayout.addWidget(self.btn20, 2, 0, 1, 1)

        self.btn71 = QPushButton(self.gridLayoutWidget)
        self.btn71.setObjectName(u"btn71")
        sizePolicy1.setHeightForWidth(self.btn71.sizePolicy().hasHeightForWidth())
        self.btn71.setSizePolicy(sizePolicy1)
        self.btn71.setCheckable(True)

        self.gridLayout.addWidget(self.btn71, 7, 1, 1, 1)

        self.btn16 = QPushButton(self.gridLayoutWidget)
        self.btn16.setObjectName(u"btn16")
        sizePolicy1.setHeightForWidth(self.btn16.sizePolicy().hasHeightForWidth())
        self.btn16.setSizePolicy(sizePolicy1)
        self.btn16.setCheckable(True)

        self.gridLayout.addWidget(self.btn16, 1, 6, 1, 1)

        self.btn42 = QPushButton(self.gridLayoutWidget)
        self.btn42.setObjectName(u"btn42")
        sizePolicy1.setHeightForWidth(self.btn42.sizePolicy().hasHeightForWidth())
        self.btn42.setSizePolicy(sizePolicy1)
        self.btn42.setCheckable(True)

        self.gridLayout.addWidget(self.btn42, 4, 2, 1, 1)

        self.btn47 = QPushButton(self.gridLayoutWidget)
        self.btn47.setObjectName(u"btn47")
        sizePolicy1.setHeightForWidth(self.btn47.sizePolicy().hasHeightForWidth())
        self.btn47.setSizePolicy(sizePolicy1)
        self.btn47.setCheckable(True)

        self.gridLayout.addWidget(self.btn47, 4, 7, 1, 1)

        self.btn13 = QPushButton(self.gridLayoutWidget)
        self.btn13.setObjectName(u"btn13")
        sizePolicy1.setHeightForWidth(self.btn13.sizePolicy().hasHeightForWidth())
        self.btn13.setSizePolicy(sizePolicy1)
        self.btn13.setCheckable(True)

        self.gridLayout.addWidget(self.btn13, 1, 3, 1, 1)

        self.btn32 = QPushButton(self.gridLayoutWidget)
        self.btn32.setObjectName(u"btn32")
        sizePolicy1.setHeightForWidth(self.btn32.sizePolicy().hasHeightForWidth())
        self.btn32.setSizePolicy(sizePolicy1)
        self.btn32.setCheckable(True)

        self.gridLayout.addWidget(self.btn32, 3, 2, 1, 1)

        self.btn12 = QPushButton(self.gridLayoutWidget)
        self.btn12.setObjectName(u"btn12")
        sizePolicy1.setHeightForWidth(self.btn12.sizePolicy().hasHeightForWidth())
        self.btn12.setSizePolicy(sizePolicy1)
        self.btn12.setCheckable(True)

        self.gridLayout.addWidget(self.btn12, 1, 2, 1, 1)

        self.btn70 = QPushButton(self.gridLayoutWidget)
        self.btn70.setObjectName(u"btn70")
        sizePolicy1.setHeightForWidth(self.btn70.sizePolicy().hasHeightForWidth())
        self.btn70.setSizePolicy(sizePolicy1)
        self.btn70.setCheckable(True)

        self.gridLayout.addWidget(self.btn70, 7, 0, 1, 1)

        self.btn22 = QPushButton(self.gridLayoutWidget)
        self.btn22.setObjectName(u"btn22")
        sizePolicy1.setHeightForWidth(self.btn22.sizePolicy().hasHeightForWidth())
        self.btn22.setSizePolicy(sizePolicy1)
        self.btn22.setCheckable(True)

        self.gridLayout.addWidget(self.btn22, 2, 2, 1, 1)

        self.btn36 = QPushButton(self.gridLayoutWidget)
        self.btn36.setObjectName(u"btn36")
        sizePolicy1.setHeightForWidth(self.btn36.sizePolicy().hasHeightForWidth())
        self.btn36.setSizePolicy(sizePolicy1)
        self.btn36.setCheckable(True)

        self.gridLayout.addWidget(self.btn36, 3, 6, 1, 1)

        self.btn01 = QPushButton(self.gridLayoutWidget)
        self.btn01.setObjectName(u"btn01")
        sizePolicy1.setHeightForWidth(self.btn01.sizePolicy().hasHeightForWidth())
        self.btn01.setSizePolicy(sizePolicy1)
        self.btn01.setAutoFillBackground(False)
        self.btn01.setCheckable(True)
        self.btn01.setChecked(False)

        self.gridLayout.addWidget(self.btn01, 0, 1, 1, 1)

        self.btn27 = QPushButton(self.gridLayoutWidget)
        self.btn27.setObjectName(u"btn27")
        sizePolicy1.setHeightForWidth(self.btn27.sizePolicy().hasHeightForWidth())
        self.btn27.setSizePolicy(sizePolicy1)
        self.btn27.setCheckable(True)

        self.gridLayout.addWidget(self.btn27, 2, 7, 1, 1)

        self.btn05 = QPushButton(self.gridLayoutWidget)
        self.btn05.setObjectName(u"btn05")
        sizePolicy1.setHeightForWidth(self.btn05.sizePolicy().hasHeightForWidth())
        self.btn05.setSizePolicy(sizePolicy1)
        self.btn05.setCheckable(True)

        self.gridLayout.addWidget(self.btn05, 0, 5, 1, 1)

        self.btn33 = QPushButton(self.gridLayoutWidget)
        self.btn33.setObjectName(u"btn33")
        sizePolicy1.setHeightForWidth(self.btn33.sizePolicy().hasHeightForWidth())
        self.btn33.setSizePolicy(sizePolicy1)
        self.btn33.setCheckable(True)

        self.gridLayout.addWidget(self.btn33, 3, 3, 1, 1)

        self.btn52 = QPushButton(self.gridLayoutWidget)
        self.btn52.setObjectName(u"btn52")
        sizePolicy1.setHeightForWidth(self.btn52.sizePolicy().hasHeightForWidth())
        self.btn52.setSizePolicy(sizePolicy1)
        self.btn52.setCheckable(True)

        self.gridLayout.addWidget(self.btn52, 5, 2, 1, 1)

        self.btn15 = QPushButton(self.gridLayoutWidget)
        self.btn15.setObjectName(u"btn15")
        sizePolicy1.setHeightForWidth(self.btn15.sizePolicy().hasHeightForWidth())
        self.btn15.setSizePolicy(sizePolicy1)
        self.btn15.setCheckable(True)

        self.gridLayout.addWidget(self.btn15, 1, 5, 1, 1)

        self.btn53 = QPushButton(self.gridLayoutWidget)
        self.btn53.setObjectName(u"btn53")
        sizePolicy1.setHeightForWidth(self.btn53.sizePolicy().hasHeightForWidth())
        self.btn53.setSizePolicy(sizePolicy1)
        self.btn53.setCheckable(True)

        self.gridLayout.addWidget(self.btn53, 5, 3, 1, 1)

        self.btn61 = QPushButton(self.gridLayoutWidget)
        self.btn61.setObjectName(u"btn61")
        sizePolicy1.setHeightForWidth(self.btn61.sizePolicy().hasHeightForWidth())
        self.btn61.setSizePolicy(sizePolicy1)
        self.btn61.setCheckable(True)

        self.gridLayout.addWidget(self.btn61, 6, 1, 1, 1)

        self.btn64 = QPushButton(self.gridLayoutWidget)
        self.btn64.setObjectName(u"btn64")
        sizePolicy1.setHeightForWidth(self.btn64.sizePolicy().hasHeightForWidth())
        self.btn64.setSizePolicy(sizePolicy1)
        self.btn64.setCheckable(True)

        self.gridLayout.addWidget(self.btn64, 6, 4, 1, 1)

        self.btn65 = QPushButton(self.gridLayoutWidget)
        self.btn65.setObjectName(u"btn65")
        sizePolicy1.setHeightForWidth(self.btn65.sizePolicy().hasHeightForWidth())
        self.btn65.setSizePolicy(sizePolicy1)
        self.btn65.setCheckable(True)

        self.gridLayout.addWidget(self.btn65, 6, 5, 1, 1)

        self.btn11 = QPushButton(self.gridLayoutWidget)
        self.btn11.setObjectName(u"btn11")
        sizePolicy1.setHeightForWidth(self.btn11.sizePolicy().hasHeightForWidth())
        self.btn11.setSizePolicy(sizePolicy1)
        self.btn11.setCheckable(True)

        self.gridLayout.addWidget(self.btn11, 1, 1, 1, 1)

        self.pushButton = QPushButton(self.centralwidget)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(170, 420, 151, 71))
        font1 = QFont()
        font1.setFamilies([u"Bradley Hand ITC"])
        font1.setPointSize(12)
        self.pushButton.setFont(font1)
        self.pushButton.setIconSize(QSize(30, 30))
        self.pushButton_2 = QPushButton(self.centralwidget)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(350, 420, 171, 71))
        self.pushButton_2.setFont(font1)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 934, 18))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.btn00.clicked.connect(MainWindow.send00)
        self.btn01.clicked.connect(MainWindow.send01)
        self.btn02.clicked.connect(MainWindow.send02)
        self.btn03.clicked.connect(MainWindow.send03)
        self.btn04.clicked.connect(MainWindow.send04)
        self.btn05.clicked.connect(MainWindow.send05)
        self.btn06.clicked.connect(MainWindow.send06)
        self.btn07.clicked.connect(MainWindow.send07)
        self.btn10.clicked.connect(MainWindow.send10)
        self.btn11.clicked.connect(MainWindow.send11)
        self.btn12.clicked.connect(MainWindow.send12)
        self.btn13.clicked.connect(MainWindow.send13)
        self.btn14.clicked.connect(MainWindow.send14)
        self.btn15.clicked.connect(MainWindow.send15)
        self.btn16.clicked.connect(MainWindow.send16)
        self.btn17.clicked.connect(MainWindow.send17)
        self.btn20.clicked.connect(MainWindow.send20)
        self.btn21.clicked.connect(MainWindow.send21)
        self.btn22.clicked.connect(MainWindow.send22)
        self.btn23.clicked.connect(MainWindow.send23)
        self.btn24.clicked.connect(MainWindow.send24)
        self.btn25.clicked.connect(MainWindow.send25)
        self.btn26.clicked.connect(MainWindow.send26)
        self.btn27.clicked.connect(MainWindow.send27)
        self.btn30.clicked.connect(MainWindow.send30)
        self.btn31.clicked.connect(MainWindow.send31)
        self.btn32.clicked.connect(MainWindow.send32)
        self.btn33.clicked.connect(MainWindow.send33)
        self.btn34.clicked.connect(MainWindow.send34)
        self.btn35.clicked.connect(MainWindow.send35)
        self.btn36.clicked.connect(MainWindow.send36)
        self.btn37.clicked.connect(MainWindow.send37)
        self.btn40.clicked.connect(MainWindow.send40)
        self.btn41.clicked.connect(MainWindow.send41)
        self.btn42.clicked.connect(MainWindow.send42)
        self.btn43.clicked.connect(MainWindow.send43)
        self.btn44.clicked.connect(MainWindow.send44)
        self.btn45.clicked.connect(MainWindow.send45)
        self.btn46.clicked.connect(MainWindow.send46)
        self.btn47.clicked.connect(MainWindow.send47)
        self.btn50.clicked.connect(MainWindow.send50)
        self.btn51.clicked.connect(MainWindow.send51)
        self.btn52.clicked.connect(MainWindow.send52)
        self.btn53.clicked.connect(MainWindow.send53)
        self.btn54.clicked.connect(MainWindow.send54)
        self.btn55.clicked.connect(MainWindow.send55)
        self.btn56.clicked.connect(MainWindow.send56)
        self.btn57.clicked.connect(MainWindow.send57)
        self.btn60.clicked.connect(MainWindow.send60)
        self.btn61.clicked.connect(MainWindow.send61)
        self.btn62.clicked.connect(MainWindow.send62)
        self.btn63.clicked.connect(MainWindow.send63)
        self.btn64.clicked.connect(MainWindow.send64)
        self.btn65.clicked.connect(MainWindow.send65)
        self.btn66.clicked.connect(MainWindow.send66)
        self.btn67.clicked.connect(MainWindow.send67)
        self.btn70.clicked.connect(MainWindow.send70)
        self.btn71.clicked.connect(MainWindow.send71)
        self.btn72.clicked.connect(MainWindow.send72)
        self.btn73.clicked.connect(MainWindow.send73)
        self.btn74.clicked.connect(MainWindow.send74)
        self.btn75.clicked.connect(MainWindow.send75)
        self.btn76.clicked.connect(MainWindow.send76)
        self.btn77.clicked.connect(MainWindow.send77)
        self.pushButton_2.clicked.connect(MainWindow.start)
        self.pushButton.clicked.connect(MainWindow.map)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.btn30.setText("")
        self.btn77.setText(QCoreApplication.translate("MainWindow", u"end", None))
        self.btn76.setText("")
        self.btn37.setText("")
        self.btn26.setText("")
        self.btn67.setText("")
        self.btn23.setText("")
        self.btn60.setText("")
        self.btn46.setText("")
        self.btn73.setText("")
        self.btn50.setText("")
        self.btn44.setText("")
        self.btn10.setText("")
        self.btn56.setText("")
        self.btn02.setText("")
        self.btn41.setText("")
        self.btn43.setText("")
        self.btn51.setText("")
        self.btn21.setText("")
        self.btn07.setText("")
        self.btn14.setText("")
        self.btn25.setText("")
        self.btn34.setText("")
        self.btn45.setText("")
        self.btn00.setText(QCoreApplication.translate("MainWindow", u"start", None))
        self.btn24.setText("")
        self.btn55.setText("")
        self.btn57.setText("")
        self.btn74.setText("")
        self.btn63.setText("")
        self.btn54.setText("")
        self.btn04.setText("")
        self.btn31.setText("")
        self.btn40.setText("")
        self.btn06.setText("")
        self.btn66.setText("")
        self.btn72.setText("")
        self.btn17.setText("")
        self.btn62.setText("")
        self.btn03.setText("")
        self.btn35.setText("")
        self.btn75.setText("")
        self.btn20.setText("")
        self.btn71.setText("")
        self.btn16.setText("")
        self.btn42.setText("")
        self.btn47.setText("")
        self.btn13.setText("")
        self.btn32.setText("")
        self.btn12.setText("")
        self.btn70.setText("")
        self.btn22.setText("")
        self.btn36.setText("")
        self.btn01.setText("")
        self.btn27.setText("")
        self.btn05.setText("")
        self.btn33.setText("")
        self.btn52.setText("")
        self.btn15.setText("")
        self.btn53.setText("")
        self.btn61.setText("")
        self.btn64.setText("")
        self.btn65.setText("")
        self.btn11.setText("")
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"clear map", None))
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"start", None))
    # retranslateUi

